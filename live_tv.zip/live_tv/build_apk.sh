#!/bin/sh
# Chay trong thu muc nay: sh build_apk.sh
set -e
flutter create --platforms=android --project-name live_tv .
M=android/app/src/main/AndroidManifest.xml
grep -q 'android.permission.INTERNET' $M || sed -i 's|<application|<uses-permission android:name="android.permission.INTERNET"/>\n    <application|' $M
grep -q usesCleartextTraffic $M || sed -i 's|<application|<application android:usesCleartextTraffic="true"|' $M
flutter pub get
flutter build apk --release
echo "APK: build/app/outputs/flutter-apk/app-release.apk"
